/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;

public class Main{
	public static void main(String[] args) {
		
		    Scanner enterScanner = new Scanner(System.in);
		    int num_1;
		    int num_2;
		    System.out.println("digite o primeiro numero:");
		    num_1 = enterScanner.nextInt();
		    System.out.println("digite o segundo numero:");
		    num_2 = enterScanner.nextInt();
		    int c = num_1 + num_2;
		    System.out.println("O resultado da soma:" + c);
		    
		    
		}
	}